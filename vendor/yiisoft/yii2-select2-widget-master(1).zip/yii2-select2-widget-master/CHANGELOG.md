# Changelog

All Notable changes to yii2-select2-widget will be documented in this file.

## 0.1.2

### Added
- Code tests. (vova07)
- Events support. (vova07)

### Changed

- Extension skeleton. (vova07)
 
## 0.1.1

- Switch to bower package of Select2 plugin (omnilight)

## 0.1.0

- Initial release (vova07)